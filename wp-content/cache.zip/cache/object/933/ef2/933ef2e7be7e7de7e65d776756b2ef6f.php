\~xX<?php exit; ?>a:1:{s:7:"content";O:8:"stdClass":23:{s:2:"ID";s:3:"191";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-12-20 18:37:12";s:13:"post_date_gmt";s:19:"2015-12-20 18:37:12";s:12:"post_content";s:4166:"The whole purpose of <strong>insurance</strong> is to maintain your <strong>financial stability</strong>. A good insurance policy ensures that you are not caught out when certain <strong>unexpected</strong> costs arise. Nowhere is this more obvious than when it comes to your car.

<h2>Car Insurance</h2>

Every driver needs car insurance. It protects you financially from the costs of accidents, enabling you to repair or <strong>replace</strong> your car following a wreck. Your policy generally provides a certain amount of coverage for medical costs, as well as an amount for your vehicle, and each figure is calculated separately.

<h4>Your insurance premiums are calculated from several factors:</h4>

*The make and model of your car.

*Your age and sex.

*Your personal driving record.

*Where and how much you normally drive the car.

*The amount of coverage you want to carry.

As a general rule, adult women have the lowest <strong>premiums</strong>, and young men the highest. Your state will usually require a certain minimum level of insurance, and if you have a car loan your bank will have its own requirements. After all, they want their money regardless of what happens to the car.

<h2>What is Gap Insurance?</h2>

<strong>Gap insurance</strong> is designed to cover you when your car is totalled and you still owe money on the vehicle. The reason it exists is that once your vehicle leaves the lot, its value is no longer tied to the amount of your outstanding loan. For some desirable vehicles, this is not an issue as they depreciate more slowly than you pay off your loan. <strong>For other vehicles, the value depreciates much more rapidly than the loan.</strong>

<h4>A gap insurance policy covers the difference between the Blue Book value of your vehicle (what your insurer pays out), and the acutal amount you owe on it.</h4>

For example, if you owe $15,000 on your vehicle but the Blue Book value is only $10,000 you need to pay off the remaining $5,000 on the loan as well as come up with the money for a down payment on its replacement.

Gap insurance covers that $5,000 so you don't have to.

<h2>So Who Needs Gap Insurance?</h2>

Not everyone needs gap insurance. For example, some Jeeps hold their value very well, so once you have paid off a few thousand dollars it will almost always be worth more than the loan. However, that's not always the case for every vehicle.

The obvious answer is when you owe more than the car is worth, but not everyone knows the value of their vehicle, but there are certain guidelines that can let you know if you are more likely to need gap insurance than not.

<h4>For the first two years of your loan</h4>

No matter how well your particular model holds its value, every car owner has to deal with the fact that your <strong>new car</strong> becomes a <strong>used car</strong> the moment it leaves the lot. At least ten to fifteen percent of the value vanishes instantly. Gap insurance covers that drop in value, so it is a good idea to hold for at least the first year or two to give you time to pay down the loan. This is particularly important when you have a longer than usual term, as the longer the loan, the more time it takes for you to build up value.

<h4>If you drive a lot</h4>

The more you drive, the faster your vehicle depreciates, so if you drive a lot more than average, usually about 15,000 miles a year or 1,250 miles per month, you should probably carry gap insurance.

<h4>If you have a model that is frequently stolen</h4>

Some cars are more likely to be stolen than others, and thieves generally look for newer cars over older ones. This means that if your car is stolen it's most likely to happen before you have paid down the loan enough to build up equity in the vehicle.

It's always best to look into these things as soon as you can, because insurance is all about preplanning. The earlier you can prepare for something, the less likely you are to be surprised if it happens. You should never have to spend your downpayment on the next vehicle paying off the loan on its predecessor. A little careful planning and some gap insurance means you never have to.

&nbsp;";s:10:"post_title";s:46:"Life Insurance Guide (Part XV) - Gap Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:42:"life-insurance-guide-part-xv-gap-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-12-20 18:37:12";s:17:"post_modified_gmt";s:19:"2015-12-20 18:37:12";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=191";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}}