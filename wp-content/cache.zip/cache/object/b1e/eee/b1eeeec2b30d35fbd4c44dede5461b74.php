�xX<?php exit; ?>a:1:{s:7:"content";O:8:"stdClass":24:{s:2:"ID";i:85;s:11:"post_author";s:1:"1";s:9:"post_date";s:19:"2015-10-18 13:15:50";s:13:"post_date_gmt";s:19:"2015-10-18 13:15:50";s:12:"post_content";s:2899:"<p>Navigating through the world of life insurance can be very complicated. Especially now with Obama Care, Healthcare.gov, and Open Enrollment Periods. Getting a health insurance policy for yourself shouldn't be.</p>

<p>When working with National Insurance Advisors you will be assigned a personal and licensed insurance advisor which will determine your unique needs and find the best health insurance policy for those needs at the best rate. </p>

<p>Whether it be individual insurance for you or your family or a group insurance policy for your business, we can handle it.</p>

<p>We work with only the most reputable insurance companies in the healthcare industry some which include:</p>

<p>
Aetna<br>
Humana<br>
Cigna<br>
Blue Cross & Blue Shield<br>
United Healthcare<br>
Kaiser Permanente<br>
</p>

<h2>Individual & Family Policies</h2>

<h3>Compare New Policies and Quotes</h3>

<p>Many issues can arise when finding an individual health insurance policy. Such as, Doctor’s covered, deductible costs, in network, and out of network costs, which procedures are covered, maximum out of pocket costs and many more.</p>

<p>Along with help and suggestions from us, we also work with multiple top health insurance carriers who compete for your business to help you get the lowest possible quotes with the best coverage.</p>

<h3>Existing Policy Help</h3>
<p>When working with a health insurance carrier, many issues can arise such as claims denial and high deductible costs which insurance carriers can make difficult to understand.</p>

<p>We work with you understanding your issues with your current policy and can improve your same policy with other insurance carriers willing to compete for your business.</p>

<h2>Group Policies For Businesses</h2>

<h3>Compare New Policies and Quotes</h3>

<p>Finding the right policy for you and your employees can be a daunting task. Especially when your employees depend on you. Luckily, we are here by your side.</p>

<p>Growing your business should be your main focus along with saving money on health insurance for your employees. Getting you top quotes from leading health insurance companies. </p>

<h3>Existing Policy Help</h3>

<p>Along with helping with many of your policy questions such as how much to contribute, tax deductible issues, and many others, we can help save you money per employee.</p>

<p>We understand the many needs of business owners on growing their business and we help them get leading healthcare from top health insurance companies.</p>

<h2>Conclusion</h2>

<p>Whether you are looking for an Individual, Family, or Group Policy, our licensed advisors are ready to help.</p>

<p>Once assigned to an advisor we gather information to give you a custom proposal. Buying a policy from us will ensure a lifetime of peace of mind and insurance help for all of your needs. </p>";s:10:"post_title";s:16:"Health Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:6:"closed";s:11:"ping_status";s:6:"closed";s:13:"post_password";s:0:"";s:9:"post_name";s:16:"health-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2016-11-28 15:06:15";s:17:"post_modified_gmt";s:19:"2016-11-28 15:06:15";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";i:0;s:4:"guid";s:38:"http://famouspixel.com/nia/?page_id=85";s:10:"menu_order";i:0;s:9:"post_type";s:4:"page";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";s:6:"filter";s:3:"raw";}}