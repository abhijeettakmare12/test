\~xX<?php exit; ?>a:1:{s:7:"content";O:8:"stdClass":23:{s:2:"ID";s:3:"183";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-11-27 19:46:42";s:13:"post_date_gmt";s:19:"2015-11-27 19:46:42";s:12:"post_content";s:3153:"<strong>Life insurance</strong> is by no means the only kind of insurance avaiable; nor is it the only kind you should regularly carry. In addition to life and car insurance, it is also a good idea for most people to carry disability insurance.

<h2>The Difference Between Disability and Life Insurance</h2>

The biggest difference between life insurance and disability insurance is that life insurance exists to help you take care of your responisibilities after you're gone, while disability insurance exists to help take care of you.

<h4>The Two Main Types of Disability Insurance</h4>

There are two main types of disability insurance, <strong>long-term disability</strong>, or LTD, and <strong>short-term disability</strong>. Both work essentially the same way. You pay regular premiums while employed, so that your insurance company will replace your income should you become unable to work. While there are a number of differences between the two, the basics are identical.

<h4>Short Term Disability Insurance</h4>

As the name suggests, short-term disability insurance provides income replacement coverage in the short term. It generally starts paying almost immediately, but the benefit term is distinctly limited. It works if you break your arm, not if you have an injury that renders you permanently unable to work. In most cases, the benefits will last no more than six months at the most. It's an immediate patch for the problem.

<h4>Long Term Disability Insurance</h4>

Long-term disability insurance is more of a way to deal with permanent or at least near-permanent disability. Unlike short-term disability, it takes a while for the benefits to kick in, but they also last much longer once they do. It's a trade-off.

Some long-term policies can take you right up to retirement age, while others only last a couple of years, so it's worth the effort to take some time and learn exactly what kind of plan you have.

<h4>Alternatives to Disability Insurance</h4>

There are two main alternatives to disability insurance: Self-insurance, and family resources. The first is simple, burn through your savings while you are unable to work. The second involves throwing yourself on the mercy of others, which has its own psychological costs.

<h4>Benefits of Disability Insurance</h4>

The biggest benefit of disability insurance is that it provides a safety net. You can keep your savings and retirement plan even if you cannot work. It is usually less of an income than you would get from working, often capped at about 60% of your gross income, but it is also considered after-tax dollars, which can offset some of the difference. Finally, you have complete control over the money, with no restrictions.

<h4>Drawbacks of Disability Insurance</h4>

&nbsp;No matter how good your disability policy may be, it cannot substitute for a good life insurance policy because it ends with you do. There are also limits on what it will cover, and you may find yourself having to go back to work in a much lower paying field than you are used to depending on how the policy defines disability.

Get one, but don't forget your life insurance.

&nbsp;";s:10:"post_title";s:54:"Life Insurance Guide (Part XII) - Disability Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:50:"life-insurance-guide-part-xii-disability-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-27 19:46:42";s:17:"post_modified_gmt";s:19:"2015-11-27 19:46:42";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=183";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}}