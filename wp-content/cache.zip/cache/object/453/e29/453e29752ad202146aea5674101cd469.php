�xX<?php exit; ?>a:1:{s:7:"content";O:8:"stdClass":24:{s:2:"ID";i:6;s:11:"post_author";s:1:"1";s:9:"post_date";s:19:"2015-10-17 04:10:28";s:13:"post_date_gmt";s:19:"2015-10-17 04:10:28";s:12:"post_content";s:1666:"<p>At National Insurance Advisors, we take pride us in being one of the leading online insurance brokerage firms who advise and custom tailor policies on a day to day basis.</p>

<p>What differentiates us from our competitors is the highest level of customer service we give to our clients. Here are some of the following key differences: </p>

<h2>Quality Customer Support</h2>
<p>When calling in, we assign you an advisor and stick with that advisor for the rest of your life.</p>

<p>We have access to many different mediums of  communication and can choose the one which fits you best. Whether it be via email, voice, or live chat we work around your busy schedule and help you.</p>

<h2>Unbiased Expert Advice</h2>
<p>When calling in, every single one of our advisors are licensed professionals and can help you with any insurance question you may have. We are experts in multiple types of policies and can advise you properly.</p>

<p>We can help you choose and compare quotes for the right insurance company for you. We don't favor any insurance companies and choose the one which is right for you.</p>

<h2>Real And Accurate Quoting</h2>
<p>At NIA we use custom internal tools which are linked up to insurance carriers and will give you the most updated information. We assess each one of our clients needs individually to give them an accurate quote rather a one size fits all solution.</p>

<h2>Conclusion</h2>
<p>What separates us from everyone else is the quality customer support we give and the expert custom advice to each one of our clients.</p>

<p>When choosing where to buy insurance we always make sure our clients are #1.</p>";s:10:"post_title";s:8:"ABOUT US";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:6:"closed";s:11:"ping_status";s:6:"closed";s:13:"post_password";s:0:"";s:9:"post_name";s:8:"about-us";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-13 16:48:23";s:17:"post_modified_gmt";s:19:"2015-11-13 16:48:23";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";i:0;s:4:"guid";s:38:"http://localhost/sandip/nia/?page_id=6";s:10:"menu_order";i:0;s:9:"post_type";s:4:"page";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";s:6:"filter";s:3:"raw";}}