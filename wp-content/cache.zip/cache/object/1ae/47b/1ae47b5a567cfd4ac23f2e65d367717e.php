\~xX<?php exit; ?>a:1:{s:7:"content";O:8:"stdClass":23:{s:2:"ID";s:3:"178";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-11-16 20:17:24";s:13:"post_date_gmt";s:19:"2015-11-16 20:17:24";s:12:"post_content";s:4217:"Many employers offer <strong>group life insurance</strong> to their employees. For most people, it's just another employment benefit they tick off and then forget about. Sure, it's a benefit, but it's not one many people normally think about.

<h2>Understanding Group Life Insurance</h2>

The most important word in understanding the differences involved in group life insurance is the word "group." Everything about the policy applies to the group, not to you as an individual. <strong>You don't even hold the policy in your own name, you are merely covered by it.</strong> Here are some points to remember.

*Based on the group risk, not your individual risk

*Usually no individual medical exam

*Policy remains active as long as you remain in the group

*Beneficial for high risk individuals because the risk is shared across the group

<h2>Why Group Life Insurance is Never Your Perfect Solution</h2>

You shouldn't just turn down your employer's <strong>group life insurance policy</strong>, but it's&nbsp;a good idea not to rely on it either. When you buy your own <strong>life insurance</strong> policy, you tailor it to meet your needs. If you need it to cover your <strong>mortgage</strong>, or your <strong>student loan</strong>, then you ensure you get a policy that does.

Group life insurance doesn't give you that flexibility. It usually provides a fixed amount of coverage, from as low as $10,000 to perhaps $100,000. Alternatively, it may offer one or two years of your <strong>base</strong> salary. It's a lot better than no insurance, but a lot less than your own <strong>term life&nbsp;insurance</strong> policy can offer.

It's also imperfect because <strong>you cannot take it with you when you leave your job</strong>.

<h4><strong>Now, you may say "What about portable life insurance?&nbsp;Can't you&nbsp;keep that when you change jobs?"</strong></h4>

Well, the truth of the matter is somewhere in between what you might want and what you might fear. Yes, if you have a <strong>portable life insurance policy</strong> on your employer's <strong>group life plan</strong> you can convert it to an <strong>individual policy</strong> when you leave their employ. So in that sense, you can take it with you.

However, what that doesn't include is the fact that the converted individual policy won't end up looking quite like the original.

Group policies offer low premiums because the risk is shared across the entire group, often including the employer. In many cases, the employer even subsidizes your premiums.

<h4>When you convert it to an individual plan, all that goes away.</h4>

*You no longer share the risk with the group

*Your employer no longer subsidizes your premiums

<strong>What all this means is that while your coverage may not change, your premiums will.</strong> In fact, your premiums are likely to skyrocket. You can easily end up paying a lot more money for coverage that doesn't actually meet your needs. That's not usually considered a good idea.

<h2>So Should You Join Your Employer's Group Life Insurance Plan?</h2>

For most people, the answer depends on the numbers. If the plan is sufficiently subsidized, it may cost you very little or no money to join the policy; in that case there really is no reason not to join.

Older people, along with some others,&nbsp;can also benefit from employer plans. If you are in a high-risk group, such as as being an older smoker, you may find the group policy is much more affordable than anything you could get on your own. In such a case, your group plan <strong>may</strong> be your best available option.

<h2>Putting It All Together</h2>

<strong>No group life insurance plan is ever a subsitute for your own comprehensive&nbsp;individual policy.</strong> It can't be, it's a "one size fits all" choice rather than something individually tailored to your unique needs. At the same time, it's often a very good inexpensive supplement to your own more complete policy.

Now in some cases, it may be your best choice. If that's true for you, then it's probably a good idea to take the policy they offer and then spend some time working out how to reduce your risk factors so you can get a better policy on your own.

&nbsp;";s:10:"post_title";s:69:"Life Insurance Guide (Part X) - What About Your Employer's Insurance?";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:63:"life-insurance-guide-part-x-what-about-your-employers-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-16 20:17:24";s:17:"post_modified_gmt";s:19:"2015-11-16 20:17:24";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=178";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}}