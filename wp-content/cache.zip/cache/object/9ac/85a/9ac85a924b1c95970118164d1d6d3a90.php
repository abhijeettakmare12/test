\~xX<?php exit; ?>a:1:{s:7:"content";O:8:"stdClass":23:{s:2:"ID";s:3:"176";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-11-13 21:28:02";s:13:"post_date_gmt";s:19:"2015-11-13 21:28:02";s:12:"post_content";s:4440:"So you sent off your <strong>life insurance</strong> application a while ago, and now you've finally got the approval back. That means you're done? Right? Actually, no it doesn't. It means you're past the biggest hurdles, but you're far from done. An <strong>approved</strong> life insurance policy isn't the same as an <strong>active</strong> life insurance policy, and you're not finished until your policy is active.

<h2>Your Policy Is Not Active Until You Make The First Payment</h2>

That's right, until you make that <strong>first payment</strong>, you're <strong>not</strong> covered. A contract requires an <strong>exchange of value</strong>, and until you make a payment that hasn't happened. That doesn't mean you send off a payment the moment you get the approval; there are a few more steps before that happens, but it does set things in motion.

<h2>What To Do When You Receive Your Approval</h2>

There are several steps you should follow between receiving your approval and actually making that all-important first payment. Some of them your insurer requires, others are just very good ideas. You have to follow some of them, but it's in your best interest to follow all of them, not just the ones your insurance company wants you to.

<h4>1: Review Your Policy</h4>

This should be obvious, but sometimes the obvious still needs a reminder before it gets done. Just because the underwriter approved you for a policy does not mean that they approved you for a policy exactly as you requested. Now sometimes, that's exactly what it does mean, but other times it may be that the underwriter determined that your love for hang gliding, or perhaps your diabetes, kicks you up&nbsp;a risk category so they want a <strong>higher premium</strong>. They may also have offered you a&nbsp;different&nbsp;term or even amount of coverage.&nbsp;If that's the case, you want to know it before you sign on the dotted line.

&nbsp;If it's only a little different, you may be best off going ahead with it anyway, if not you can always explore alternatives. At least, you can if you know about the changes.

<h4>2: Check Your Classification</h4>

With the approval form comes your <strong>rate classification</strong>. This is the insurance&nbsp;company's&nbsp;assessment of just&nbsp;how much&nbsp;of a risk you are. Different companies&nbsp;have different names, but they all have a similar system. If you have a really good classification, this information will be on your approval. If you happen to fall into the best class, often called something like Preferred Elite, or maybe Preferred Plus, you may want to increase your policy now since you are unlikely to be able to get a better deal.

<h4>3: Accept The Policy</h4>

Now you can accept the policy and you are ready to move on to the next stage. It may involve calling a broker, or dealing direct with the insurance company. It doesn't matter, all you are doing here is saying "yes."

<h4>4: Do The Paperwork</h4>

Shortly after you accept your policy, you will receive it, along with some important paperwork for you to sign and fill out. You want to keep a record of your policy, so print it out if you received it electronically. You also need to sign the papers and send them off. This signifies your <strong>formal acceptance</strong> of the policy and is the penultimate step toward activating it.

<h4>5: Make The Payment</h4>

This is it, once you make the payment, you have successfully turned your approval into an <strong>active life insurance policy</strong>. You are now covered. Most companies offer several different payment options, from annual down to monthly. As a general rule, the fewer payments you have to make, the more you save. If you do go for monthly premiums, you may want to set up automatic payments so that you don't miss one.

<h2>After You Are Insured</h2>

The process doesn't stop even after you are making your payments. Just as your insurance company cannot predict your future, neither can you. As time goes on, things change. You have kids, you pay down your mortgage. So, just as your life changes, your insurance may have to change to match it. That's why it's a good idea to do an <strong>annual review</strong> of your policy.

Spend some time going over your policy so you can be sure that it still matches your needs. That way, you can make changes as you need them.

Just remember to always pay on time.

&nbsp;

<h4>&nbsp;</h4>

&nbsp;";s:10:"post_title";s:55:"Life Insurance Guide (Part IX) - Approval Isn't the End";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:50:"life-insurance-guide-part-ix-approval-isnt-the-end";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-13 21:28:02";s:17:"post_modified_gmt";s:19:"2015-11-13 21:28:02";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=176";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}}