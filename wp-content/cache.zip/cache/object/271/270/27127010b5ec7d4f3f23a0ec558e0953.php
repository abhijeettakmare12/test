\~xX<?php exit; ?>a:1:{s:7:"content";O:8:"stdClass":23:{s:2:"ID";s:3:"195";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2016-01-03 20:35:22";s:13:"post_date_gmt";s:19:"2016-01-03 20:35:22";s:12:"post_content";s:3152:"<strong>Details matter</strong>. That is true of <strong>life insurance</strong> as it is of anything else. Details are also why it is important to judge a policy on more than just <strong>price.</strong>

Everyone has seen the TV commercials for inexpensive life insurance policies that accept everyone, and while they may look good, it's always important to pay attention to the details. Price should never be the only determinant of whether to buy a policy or not.

<h2>Watch for Exclusions</h2>

<strong>Every insurance company is in business to make a profit, and each one's premium structure reflects that</strong>. So if you see one that looks too good to be true, it probably is. That's not something unique to the insurance industry, but it is something you need to be aware of.

<h4>It's All About Exclusions</h4>

Just about every policy has <strong>exclusions</strong>. After all, what's to stop someone with a terminal diagnosis from immediately signing up for a very large policy, knowing they are only going to have to make a single payment. In most cases, that would be seen as abuse, and the company would not have to honor the policy.

The way the insurance companies handle this, and <strong>limit their liability</strong>, is by putting exclusions in their policies. In simplest terms, this means that each policy defines certain circumstances under which the company does not have to pay out to your beneficiary.

While the specifics vary from company to company, and from policy to policy, there are some basics you can rely on. If a policy is very easy to get, and has a very large payout relative to other policies, the chances are that it has a lot more exclusions.

This may not be a problem for some people, but the last person who needs&nbsp;a suprise about your life insurance policy is your beneficiary.

<h2>Always Read The Fine Print</h2>

The best way to deal with this is to always be sure and read the fine print. Regardless of where you get your policy, it has to include a list of all the circumstances in which it will and will not pay out. <strong>A policy with more conditions and limitations will cost you less because it's worth less.</strong> It's that simple.

That's why it's important to compare more than just <strong>premiums</strong> and <strong>payouts</strong> when you are choosing a policy. You have to look at the policy as a whole, and in detail, so that you know exactly what you are and are not getting for your premiums.

The key is to make a list of what is covered, and determine what matters to you. For example, some policies may not cover various <strong>pre-existing conditions</strong>, or even ones&nbsp;that are common in your family. If that's the case, it's important ot know before you sign the policy, and not leave it for your beneficiaries to discover when they are expecting a payout.

Reading the fine print and paying attention to the details makes it possible for you to make an informed decision, not an uninformed one. The more you know, the easier it is to be sure you are making the right decision. Otherwise you might as well be throwing darts while blindfolded.

&nbsp;";s:10:"post_title";s:64:"Life Insurance Guide (Part XVII)  - Pay Attention to the Details";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:59:"life-insurance-guide-part-xvii-pay-attention-to-the-details";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2016-01-03 20:35:22";s:17:"post_modified_gmt";s:19:"2016-01-03 20:35:22";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=195";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}}