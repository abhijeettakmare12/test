\~xX<?php exit; ?>a:6:{s:10:"last_error";s:0:"";s:10:"last_query";s:93:"SELECT wp_nia_posts.* FROM wp_nia_posts WHERE ID IN (195,193,191,189,186,183,180,178,176,169)";s:11:"last_result";a:10:{i:0;O:8:"stdClass":23:{s:2:"ID";s:3:"169";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-11-12 21:27:27";s:13:"post_date_gmt";s:19:"2015-11-12 21:27:27";s:12:"post_content";s:2820:"When it comes to <strong>life insurance</strong>, few things are as important as your <strong>age</strong>. <strong>Sure, age is just a number, but the insurance industry is based on numbers</strong>. Insurance is all about statistics, and the better the insurance company's numbers, the more accurately they can predict the future.

<h2>The Key to Statistics</h2>

The most important thing to remember about statistics, is that while they do a great job of predicting the future of groups, they are almost completely useless for predicting the future of individuals. So while insurance companies can generally predict the <strong>average lifespan</strong> of people of any given age, they <strong>can't predict</strong> the&nbsp;lifespan of any one individual&nbsp;in that group. They issue policies based on their best statistical information, betting that any given person will fall into the average of their group.

<h4>Age and Statistics</h4>

<strong>One result of this is that the younger you are, the easier it is to get insurance, especially for shorter terms.</strong> After all, it's much more likely that a twenty-year-old will live another twenty years than a seventy-year-old. Insurance companies use this fact, along with your medical history, to determine your basic eligibility for any particular insurance policy.

<h2>At What Age Do You Need Life Insurance?</h2>

There is no right or wrong age for life insurance. <strong>Anyone who has responsibilities to cover needs life insurance</strong>, regardless of their age.

<h4>Younger People and Life Insurance</h4>

Younger people are usually better served by <strong>term life insurance</strong>. It is generally simpler and easier to obtain, and is often a better fit for their needs. In most cases, these consumers know their financial responsibilities, and often buy their coverage to handle a specific obiligation. They often want insurance to cover things like student loans, their chidren's educations, or perhaps their mortgage; term policies are perfect for this kind of expense because you can not only predict the amount, but also the duration of the obligation.

<h4>Older People and Life Insurance</h4>

While many older people can benefit from term life insurance, they are often better positioned to benefit from <strong>permanent life insurance</strong>. They can use it as part of a diversified retirement strategy, taking advantage of the existing and usually growing <strong>cash value</strong>.

Permanent life insurance is a better fit for these people because their obligations don't tend to have a pre-determined end date. You can know to the day&nbsp;when your mortgage will be paid off some twenty-five or thirty years in advance, but you don't have that sort of advanced knowledge of how long your retirement is going to last.";s:10:"post_title";s:57:"Life Insurance Guide (Part VIII) - Age and Life Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:53:"life-insurance-guide-part-viii-age-and-life-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-12 21:27:27";s:17:"post_modified_gmt";s:19:"2015-11-12 21:27:27";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=169";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:1;O:8:"stdClass":23:{s:2:"ID";s:3:"176";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-11-13 21:28:02";s:13:"post_date_gmt";s:19:"2015-11-13 21:28:02";s:12:"post_content";s:4440:"So you sent off your <strong>life insurance</strong> application a while ago, and now you've finally got the approval back. That means you're done? Right? Actually, no it doesn't. It means you're past the biggest hurdles, but you're far from done. An <strong>approved</strong> life insurance policy isn't the same as an <strong>active</strong> life insurance policy, and you're not finished until your policy is active.

<h2>Your Policy Is Not Active Until You Make The First Payment</h2>

That's right, until you make that <strong>first payment</strong>, you're <strong>not</strong> covered. A contract requires an <strong>exchange of value</strong>, and until you make a payment that hasn't happened. That doesn't mean you send off a payment the moment you get the approval; there are a few more steps before that happens, but it does set things in motion.

<h2>What To Do When You Receive Your Approval</h2>

There are several steps you should follow between receiving your approval and actually making that all-important first payment. Some of them your insurer requires, others are just very good ideas. You have to follow some of them, but it's in your best interest to follow all of them, not just the ones your insurance company wants you to.

<h4>1: Review Your Policy</h4>

This should be obvious, but sometimes the obvious still needs a reminder before it gets done. Just because the underwriter approved you for a policy does not mean that they approved you for a policy exactly as you requested. Now sometimes, that's exactly what it does mean, but other times it may be that the underwriter determined that your love for hang gliding, or perhaps your diabetes, kicks you up&nbsp;a risk category so they want a <strong>higher premium</strong>. They may also have offered you a&nbsp;different&nbsp;term or even amount of coverage.&nbsp;If that's the case, you want to know it before you sign on the dotted line.

&nbsp;If it's only a little different, you may be best off going ahead with it anyway, if not you can always explore alternatives. At least, you can if you know about the changes.

<h4>2: Check Your Classification</h4>

With the approval form comes your <strong>rate classification</strong>. This is the insurance&nbsp;company's&nbsp;assessment of just&nbsp;how much&nbsp;of a risk you are. Different companies&nbsp;have different names, but they all have a similar system. If you have a really good classification, this information will be on your approval. If you happen to fall into the best class, often called something like Preferred Elite, or maybe Preferred Plus, you may want to increase your policy now since you are unlikely to be able to get a better deal.

<h4>3: Accept The Policy</h4>

Now you can accept the policy and you are ready to move on to the next stage. It may involve calling a broker, or dealing direct with the insurance company. It doesn't matter, all you are doing here is saying "yes."

<h4>4: Do The Paperwork</h4>

Shortly after you accept your policy, you will receive it, along with some important paperwork for you to sign and fill out. You want to keep a record of your policy, so print it out if you received it electronically. You also need to sign the papers and send them off. This signifies your <strong>formal acceptance</strong> of the policy and is the penultimate step toward activating it.

<h4>5: Make The Payment</h4>

This is it, once you make the payment, you have successfully turned your approval into an <strong>active life insurance policy</strong>. You are now covered. Most companies offer several different payment options, from annual down to monthly. As a general rule, the fewer payments you have to make, the more you save. If you do go for monthly premiums, you may want to set up automatic payments so that you don't miss one.

<h2>After You Are Insured</h2>

The process doesn't stop even after you are making your payments. Just as your insurance company cannot predict your future, neither can you. As time goes on, things change. You have kids, you pay down your mortgage. So, just as your life changes, your insurance may have to change to match it. That's why it's a good idea to do an <strong>annual review</strong> of your policy.

Spend some time going over your policy so you can be sure that it still matches your needs. That way, you can make changes as you need them.

Just remember to always pay on time.

&nbsp;

<h4>&nbsp;</h4>

&nbsp;";s:10:"post_title";s:55:"Life Insurance Guide (Part IX) - Approval Isn't the End";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:50:"life-insurance-guide-part-ix-approval-isnt-the-end";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-13 21:28:02";s:17:"post_modified_gmt";s:19:"2015-11-13 21:28:02";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=176";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:2;O:8:"stdClass":23:{s:2:"ID";s:3:"178";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-11-16 20:17:24";s:13:"post_date_gmt";s:19:"2015-11-16 20:17:24";s:12:"post_content";s:4217:"Many employers offer <strong>group life insurance</strong> to their employees. For most people, it's just another employment benefit they tick off and then forget about. Sure, it's a benefit, but it's not one many people normally think about.

<h2>Understanding Group Life Insurance</h2>

The most important word in understanding the differences involved in group life insurance is the word "group." Everything about the policy applies to the group, not to you as an individual. <strong>You don't even hold the policy in your own name, you are merely covered by it.</strong> Here are some points to remember.

*Based on the group risk, not your individual risk

*Usually no individual medical exam

*Policy remains active as long as you remain in the group

*Beneficial for high risk individuals because the risk is shared across the group

<h2>Why Group Life Insurance is Never Your Perfect Solution</h2>

You shouldn't just turn down your employer's <strong>group life insurance policy</strong>, but it's&nbsp;a good idea not to rely on it either. When you buy your own <strong>life insurance</strong> policy, you tailor it to meet your needs. If you need it to cover your <strong>mortgage</strong>, or your <strong>student loan</strong>, then you ensure you get a policy that does.

Group life insurance doesn't give you that flexibility. It usually provides a fixed amount of coverage, from as low as $10,000 to perhaps $100,000. Alternatively, it may offer one or two years of your <strong>base</strong> salary. It's a lot better than no insurance, but a lot less than your own <strong>term life&nbsp;insurance</strong> policy can offer.

It's also imperfect because <strong>you cannot take it with you when you leave your job</strong>.

<h4><strong>Now, you may say "What about portable life insurance?&nbsp;Can't you&nbsp;keep that when you change jobs?"</strong></h4>

Well, the truth of the matter is somewhere in between what you might want and what you might fear. Yes, if you have a <strong>portable life insurance policy</strong> on your employer's <strong>group life plan</strong> you can convert it to an <strong>individual policy</strong> when you leave their employ. So in that sense, you can take it with you.

However, what that doesn't include is the fact that the converted individual policy won't end up looking quite like the original.

Group policies offer low premiums because the risk is shared across the entire group, often including the employer. In many cases, the employer even subsidizes your premiums.

<h4>When you convert it to an individual plan, all that goes away.</h4>

*You no longer share the risk with the group

*Your employer no longer subsidizes your premiums

<strong>What all this means is that while your coverage may not change, your premiums will.</strong> In fact, your premiums are likely to skyrocket. You can easily end up paying a lot more money for coverage that doesn't actually meet your needs. That's not usually considered a good idea.

<h2>So Should You Join Your Employer's Group Life Insurance Plan?</h2>

For most people, the answer depends on the numbers. If the plan is sufficiently subsidized, it may cost you very little or no money to join the policy; in that case there really is no reason not to join.

Older people, along with some others,&nbsp;can also benefit from employer plans. If you are in a high-risk group, such as as being an older smoker, you may find the group policy is much more affordable than anything you could get on your own. In such a case, your group plan <strong>may</strong> be your best available option.

<h2>Putting It All Together</h2>

<strong>No group life insurance plan is ever a subsitute for your own comprehensive&nbsp;individual policy.</strong> It can't be, it's a "one size fits all" choice rather than something individually tailored to your unique needs. At the same time, it's often a very good inexpensive supplement to your own more complete policy.

Now in some cases, it may be your best choice. If that's true for you, then it's probably a good idea to take the policy they offer and then spend some time working out how to reduce your risk factors so you can get a better policy on your own.

&nbsp;";s:10:"post_title";s:69:"Life Insurance Guide (Part X) - What About Your Employer's Insurance?";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:63:"life-insurance-guide-part-x-what-about-your-employers-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-16 20:17:24";s:17:"post_modified_gmt";s:19:"2015-11-16 20:17:24";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=178";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:3;O:8:"stdClass":23:{s:2:"ID";s:3:"180";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-11-17 20:32:06";s:13:"post_date_gmt";s:19:"2015-11-17 20:32:06";s:12:"post_content";s:3899:"Whenever people have to apply for anything, one of the first questions that comes to mind is:

<h4><strong>"How Many Applications Can I Make at the Same Time?"</strong></h4>

Life insurance is no different. People want to know whether they can apply to different insurers at the same time, or if they have to wait for one to reply before they can apply to another. Obviously, waiting for anything can be nervewracking, especially if you are afraid of rejection, but that does not mean you should send off your life insurance application forms in batches.

<h4>Multiple Companies Or Multiple Policies</h4>

Now, lots of people have more than one life insurance policy. They may have one&nbsp;main one, and then take out&nbsp;another to cover a new responsibility, like a car loan. This is normal, and often easier than completely revising your main policy for what may be a short-term requirement. However, most people simply get another policy with the same insurance company.&nbsp;

Still, whether you are applying for an additional policy to cover a change in your situation, or applying for several policies at once:

<h2>There Is No Legal Limit On Life Insurance Applications</h2>

If you want to apply to every life insurance company in the country, there is no law stopping you from doing so. Sure, the postage can add up, and any possible fees, but you can do it if you want.

<h4>The Real Question Is Should You Want To?</h4>

What are the costs and benefits of multiple applications? Why would you want to apply to several companies at the same time anyway?

One reason for applying to several companies at once is simple <strong>fear</strong>; rejection can be a scary thing&nbsp;People apply to multiple companies because they are afraid they will get turned down. After all, if you try enough times,&nbsp;you're sure to succeed eventually.

Another reason for applying to multiple companies can be best described as <strong>insurance</strong>. Not all companies are equally stable, and applying to a second company gives you that extra level of security.

<h2>Concerns With Multiple Applications</h2>

When you apply to multiple companies at the same time, it tends to raise some understandable concerns.

<h4>Can You Pay For It?</h4>

One of the first concerns is the simplest. If you're approved for several policies, you have to pay several premiums. Now, one of the reasons companies as for financial information when you apply is that they want to make sure you can pay their premiums on top of your existing bills. Applying with multiple companies makes this harder, because there is more than one set of premiums to consider.

<h4>Red Flag Issues</h4>

Every industry has fraud, and insurance is no exception. If you are applying to multiple companies because you are afraid you might get turned down, you're likely to be applying for more insurance than you need, and that can set off fraud alerts. Most of the time this is easy to resolve, but sometimes it can take a while.

<h2>Costs of Multiple Companies</h2>

Doing business with multiple insurance companies can have a number of costs, some of which are more obvious than others.

<h4>Premiums</h4>

The first cost is your premiums. The more policies you have, the more premiums you have to pay. Each individual policy may not be that expensive, but three or four added together can be a significant amount.

<h4>Complexity</h4>

The second cost is complexity. The more companies you have to deal with, the more complex managing your insurance policies becomes. If you want to change your beneficiary you have to make three or four phone calls, not just one, and the change will probably go through at different times.

In the end, your best option is normally to stick with one company and work with it. It's easier to get your insurance that way, and easier to manage it once you have your policy.

Take the easy way out.";s:10:"post_title";s:73:"Live Insurance Guide (Part XI) - Applying to Multiple Insurance Companies";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:69:"live-insurance-guide-part-xi-applying-to-multiple-insurance-companies";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-17 20:32:06";s:17:"post_modified_gmt";s:19:"2015-11-17 20:32:06";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=180";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:4;O:8:"stdClass":23:{s:2:"ID";s:3:"183";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-11-27 19:46:42";s:13:"post_date_gmt";s:19:"2015-11-27 19:46:42";s:12:"post_content";s:3153:"<strong>Life insurance</strong> is by no means the only kind of insurance avaiable; nor is it the only kind you should regularly carry. In addition to life and car insurance, it is also a good idea for most people to carry disability insurance.

<h2>The Difference Between Disability and Life Insurance</h2>

The biggest difference between life insurance and disability insurance is that life insurance exists to help you take care of your responisibilities after you're gone, while disability insurance exists to help take care of you.

<h4>The Two Main Types of Disability Insurance</h4>

There are two main types of disability insurance, <strong>long-term disability</strong>, or LTD, and <strong>short-term disability</strong>. Both work essentially the same way. You pay regular premiums while employed, so that your insurance company will replace your income should you become unable to work. While there are a number of differences between the two, the basics are identical.

<h4>Short Term Disability Insurance</h4>

As the name suggests, short-term disability insurance provides income replacement coverage in the short term. It generally starts paying almost immediately, but the benefit term is distinctly limited. It works if you break your arm, not if you have an injury that renders you permanently unable to work. In most cases, the benefits will last no more than six months at the most. It's an immediate patch for the problem.

<h4>Long Term Disability Insurance</h4>

Long-term disability insurance is more of a way to deal with permanent or at least near-permanent disability. Unlike short-term disability, it takes a while for the benefits to kick in, but they also last much longer once they do. It's a trade-off.

Some long-term policies can take you right up to retirement age, while others only last a couple of years, so it's worth the effort to take some time and learn exactly what kind of plan you have.

<h4>Alternatives to Disability Insurance</h4>

There are two main alternatives to disability insurance: Self-insurance, and family resources. The first is simple, burn through your savings while you are unable to work. The second involves throwing yourself on the mercy of others, which has its own psychological costs.

<h4>Benefits of Disability Insurance</h4>

The biggest benefit of disability insurance is that it provides a safety net. You can keep your savings and retirement plan even if you cannot work. It is usually less of an income than you would get from working, often capped at about 60% of your gross income, but it is also considered after-tax dollars, which can offset some of the difference. Finally, you have complete control over the money, with no restrictions.

<h4>Drawbacks of Disability Insurance</h4>

&nbsp;No matter how good your disability policy may be, it cannot substitute for a good life insurance policy because it ends with you do. There are also limits on what it will cover, and you may find yourself having to go back to work in a much lower paying field than you are used to depending on how the policy defines disability.

Get one, but don't forget your life insurance.

&nbsp;";s:10:"post_title";s:54:"Life Insurance Guide (Part XII) - Disability Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:50:"life-insurance-guide-part-xii-disability-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-27 19:46:42";s:17:"post_modified_gmt";s:19:"2015-11-27 19:46:42";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=183";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:5;O:8:"stdClass":23:{s:2:"ID";s:3:"186";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-12-05 22:46:38";s:13:"post_date_gmt";s:19:"2015-12-05 22:46:38";s:12:"post_content";s:4237:"People may hate to talk or even thing about it, but everyone has final expenses. Be it a funeral, burial, cremation, there are always expenses associated with the very end of your term on Earth. While there are always those who take the selfish way out and let their survivors worry about it, most of us would rather not do that. This is where <strong>final expense insurance</strong> comes into the picture.

<h2>What is Final Expense Insurance?</h2>

Final expense insurance is a policy designed to specifically cover the expenses associated with your passing. In general, it covers your funeral and burial expenses, and may extend to some final medical bills or hospice care. It doesn't usually offer a&nbsp; large payout, usually between $5,000 to $25,000, but with many funerals creeping upwards of $8,000 it is more than enough to cover the financial shock of your passing. It is usually sold as a form of <strong>permanent life insurance</strong>, where you simply keep paying for the rest of your life rather than with a <strong>fixed term</strong>.

<h4>Benefits and Advantages of Final Expense Insurance</h4>

Despite its obvious limitations, many of which will be discussed later, final expense insurance does have some advantages when compared to other forms of insurance.

*It does possess a <strong>cash value</strong>. While the payout may be fairly small, it is considered an asset and so the policy does have a real value, unlike a term policy.

*Almost anyone can get coverage. <strong>Final expense insurance</strong> is often considered a form of <strong>guaranteed life insurance</strong>, so you do not usually need a medical examination. You simply fill out the application and get your policy.

*There are no restrictions on the <strong>payout</strong>. While the money is supposed to be used for the specific purpose of paying your final expenses, the insurance company cannot limit how your beneficiary spends it.

*It can be assigned directly to the <strong>funeral home</strong>. This makes it a great option for people who do not expect to have survivors, or simply wish to spare them the responsibility of having to make those decisions while grieving.

<h4>Limitations of Final Expense Insurance</h4>

As with anything else, there are tradeoffs involved with final expense insurance. It has benefits, but you have to be aware of your needs and what it doesn't do before you make the decision.

*It is relatively expensive. Because the insurance company knows they are going to have to pay out eventually, unlike with <strong>term life insurance</strong>, you generally pay larger premiums in proportion to the coverage you get with final expense insurance.

*It will not cover any other financail responsibilities you may have incurred. It's generally just enough to cover your final expenses, and won't stretch to cover anything else you might need.

<h2>Who is Final Expense Insurance Good For?</h2>

Final expense insurance is a good choice for people who are single with no outstanding responsibilities except their own final expenses. It gives them a way to clear up their final responsibilities without the need to rely on anyone else. It is also a good choice for those who find it difficult to get other forms of insurance, as it is relatively easy to get.

<h2>Alternatives to Final Expense Insurance</h2>

The simplest alternative is to simply leave enough money behind to pay your own funerary expenses. Not everyone has this option, but for those who do it is one of the simplest alternatives as there are no additional paperwork or bureaucratic requirements involved.

Another common alternative is to rely on your existing <strong>insurance policy</strong>. If you already have a comprehensive insurance policy, or policies, it is simple enough to use some of that money for final expenses. It's usually more cost-effective as well, since most other forms of insurance provide a greater payout for the <strong>premiums</strong> you pay.

In the end though, it all comes down to the combination of your needs and your available resources to determine the insurance product that is best suited to meet your needs, whether that might be final expense insurance or something completely different.";s:10:"post_title";s:58:"Life Insurance Guide (Part XIII) - Final Expense Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:54:"life-insurance-guide-part-xiii-final-expense-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-12-05 22:46:38";s:17:"post_modified_gmt";s:19:"2015-12-05 22:46:38";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=186";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:6;O:8:"stdClass":23:{s:2:"ID";s:3:"189";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-12-13 20:06:53";s:13:"post_date_gmt";s:19:"2015-12-13 20:06:53";s:12:"post_content";s:3292:"When it comes to choosing <strong>Term Life Insurance</strong>, one of the most important decisions you can make is how long a term should you buy? Needless to say, there is no one term that fits everyone's needs, but there are definitely some guidelines you can follow that make it much easier to find the right length of term for your needs.

<h2>Start With Your Needs</h2>

The first thing you should do before applying for any kind of <strong>insurance policy</strong> is make sure you understand your insurance needs. It's the same with any major decision; if you don't understand what you are doing and why you are doing it, it is very difficult to accurately determine what you need as opposed to what you only want.

Most people buy term life insurance to cover specific <strong>financial responsibilities</strong>, such as paying off a car loan, or putting children through college. The advantage of these requirements is that they are simple to figure out. You know exactly when your last car or mortgage payment should be due, or the year your children can be expected to graduate from college. In those cases, figuring a term is easy.

<h2>Consider Contributing Factors</h2>

After the nature of your responsibilities, one of the most important factors to consider is your age. While&nbsp;many life insurance policies are <strong>renewable</strong>, that may not be the case for all policies, and your premium level may not be guaranteed on a renewal.

From the insurer's perspective, the biggest difference between a <strong>permanent life insurance policy</strong> and a term life insurance policy is that the company knows they are going to have to pay out eventually (so long as you keep up with your payments), which is not always the case with term life insurance. This makes term life insurance less of a risk so the company can offer more coverage for the same <strong>premiums</strong>.

The only issue is that as you get older, the chance the company will have to pay out goes up. Naturally, this also means that the older you get, the higher your premiums are going to be. It's all about managing the company's financial risk.

<h2>What This Means for You</h2>

If you are a relatively young person, it often makes sense just to get a policy to cover the duration of your responsibility. A twenty year old with a three year car loan is fine with a three year policy just to cover paying off the car. However, as you get older, things begin to change.

<h4>Higher Premiums</h4>

It&nbsp;may sound odd, but&nbsp;you usually get significantly lower premiums for a twenty&nbsp;year policy that you get at age forty than you would for a ten year policy you get at age fifty.&nbsp;After all, the company is likely to get more money from you with the longer policy because you're making more payments. Do be aware your premiums are higher for longer policies due to the greater risk, but in most cases the age-related increase is more significant.

Now one thing you do have to watch out for is that some policies have age-related premium increases, but those usually don't come into play until retirement age.

In short, unless you know your needs are only going to be of a fixed duration, it's almost always a good idea to get a longer term policy rather than a shorter one.";s:10:"post_title";s:73:"Life Insurance Guide (Part XIV) - How Long a Term for Term Life Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:69:"life-insurance-guide-part-xiv-how-long-a-term-for-term-life-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-12-13 20:06:53";s:17:"post_modified_gmt";s:19:"2015-12-13 20:06:53";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=189";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:7;O:8:"stdClass":23:{s:2:"ID";s:3:"191";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-12-20 18:37:12";s:13:"post_date_gmt";s:19:"2015-12-20 18:37:12";s:12:"post_content";s:4166:"The whole purpose of <strong>insurance</strong> is to maintain your <strong>financial stability</strong>. A good insurance policy ensures that you are not caught out when certain <strong>unexpected</strong> costs arise. Nowhere is this more obvious than when it comes to your car.

<h2>Car Insurance</h2>

Every driver needs car insurance. It protects you financially from the costs of accidents, enabling you to repair or <strong>replace</strong> your car following a wreck. Your policy generally provides a certain amount of coverage for medical costs, as well as an amount for your vehicle, and each figure is calculated separately.

<h4>Your insurance premiums are calculated from several factors:</h4>

*The make and model of your car.

*Your age and sex.

*Your personal driving record.

*Where and how much you normally drive the car.

*The amount of coverage you want to carry.

As a general rule, adult women have the lowest <strong>premiums</strong>, and young men the highest. Your state will usually require a certain minimum level of insurance, and if you have a car loan your bank will have its own requirements. After all, they want their money regardless of what happens to the car.

<h2>What is Gap Insurance?</h2>

<strong>Gap insurance</strong> is designed to cover you when your car is totalled and you still owe money on the vehicle. The reason it exists is that once your vehicle leaves the lot, its value is no longer tied to the amount of your outstanding loan. For some desirable vehicles, this is not an issue as they depreciate more slowly than you pay off your loan. <strong>For other vehicles, the value depreciates much more rapidly than the loan.</strong>

<h4>A gap insurance policy covers the difference between the Blue Book value of your vehicle (what your insurer pays out), and the acutal amount you owe on it.</h4>

For example, if you owe $15,000 on your vehicle but the Blue Book value is only $10,000 you need to pay off the remaining $5,000 on the loan as well as come up with the money for a down payment on its replacement.

Gap insurance covers that $5,000 so you don't have to.

<h2>So Who Needs Gap Insurance?</h2>

Not everyone needs gap insurance. For example, some Jeeps hold their value very well, so once you have paid off a few thousand dollars it will almost always be worth more than the loan. However, that's not always the case for every vehicle.

The obvious answer is when you owe more than the car is worth, but not everyone knows the value of their vehicle, but there are certain guidelines that can let you know if you are more likely to need gap insurance than not.

<h4>For the first two years of your loan</h4>

No matter how well your particular model holds its value, every car owner has to deal with the fact that your <strong>new car</strong> becomes a <strong>used car</strong> the moment it leaves the lot. At least ten to fifteen percent of the value vanishes instantly. Gap insurance covers that drop in value, so it is a good idea to hold for at least the first year or two to give you time to pay down the loan. This is particularly important when you have a longer than usual term, as the longer the loan, the more time it takes for you to build up value.

<h4>If you drive a lot</h4>

The more you drive, the faster your vehicle depreciates, so if you drive a lot more than average, usually about 15,000 miles a year or 1,250 miles per month, you should probably carry gap insurance.

<h4>If you have a model that is frequently stolen</h4>

Some cars are more likely to be stolen than others, and thieves generally look for newer cars over older ones. This means that if your car is stolen it's most likely to happen before you have paid down the loan enough to build up equity in the vehicle.

It's always best to look into these things as soon as you can, because insurance is all about preplanning. The earlier you can prepare for something, the less likely you are to be surprised if it happens. You should never have to spend your downpayment on the next vehicle paying off the loan on its predecessor. A little careful planning and some gap insurance means you never have to.

&nbsp;";s:10:"post_title";s:46:"Life Insurance Guide (Part XV) - Gap Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:42:"life-insurance-guide-part-xv-gap-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-12-20 18:37:12";s:17:"post_modified_gmt";s:19:"2015-12-20 18:37:12";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=191";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:8;O:8:"stdClass":23:{s:2:"ID";s:3:"193";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2015-12-27 22:15:36";s:13:"post_date_gmt";s:19:"2015-12-27 22:15:36";s:12:"post_content";s:3622:"When it comes buying insurance, whether for your&nbsp;life, home, or car there are a number of different questions you have to ask yourself. One of those questions is whether you should go with a single insurance vendor, or spread your policies among several different insurers. As with many other things, there is no single right answer for everyone, but there is usually a right answer for you.

<h2>Benefits of a Single Insurer</h2>

There are a number of benefits that come from combining all your policies with a single insurer. For one thing, it's much simpler to deal with one company rather than several. You only have one company to deal with, and often a single bill to pay. Best of all, many insurers offer a <strong>bundle discount</strong>, where you can save money by combining all your policies under a single policy umbrella.

<h2>Benefits of Multiple Insurers</h2>

On the other hand, choosing to work with multiple insurers also has benefits. Not all insurers are created equal, and some carriers may offer better <strong>policies</strong> in one area than another. Going with multiple sources lets you take advantage of each <strong>insurance company's</strong> strengths.

Sometimes, you can get better deals by comparing companies as well.

Splitting your protection across different insurers also helps spread the risk as well, since you aren't dependent on a single provider for all your insurance needs.

<h2>Deciding Between Single and Multiple Carriers</h2>

Many people don't actually make a clear <strong>decision</strong> one way or the other. Rather than considering the competing benefits of the two approaches, they simply react. If they see a good deal from a new insurer, they jump on it; if their existing carrier offers them a bundle deal they may jump on that. Both approaches work, but it's very difficult to get the best <strong>insurance coverage</strong> for your <strong>individual needs</strong> this way.

<strong>Good decisions rely on good information</strong>, so before you decide which approach will work better for you, you need to inventory your own needs and priorities. That way you can actually make an effective choice.

Most of the time, it is a matter of balancing simplicity against flexibility. Going through a single provider is easier. You only need to worry about one set of policies and it is much easier to manage. Choosing to go through multiple providers takes more time. You have to compare policies in detail, and master each company's terminology. Still, it can make it easier to tailor your coverage to your needs.

As a rule, the simpler your insurance needs may be, the better off you are bundling everything through a single insurer. You can save both money and time, and the coverage should be fine for your needs. It lets you pay attention to your <strong>life</strong>, not your <strong>life insurance</strong>.

On the other hand, if you have more complicated insurance needs, you might really benefit from leveraging different kinds of coverage from different companies; getting <strong>term life insurance</strong> from one and <strong>permanent life insurance</strong> from another. It will take up more of your time, but your coverage will better fit your needs.

In the end, the most important thing is to take the time to sit down and figure out what&nbsp;your needs really are. Do you just need enough coverage to pay off&nbsp; your car loan? Do you have a family to support? Sitting down with the answers to those question, and any other relevant information makes it much easier to make that decision.

It is your choice. Choose wisely.";s:10:"post_title";s:54:"Life Insurance Guide (Part XVI) - One Carrier or Many?";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:49:"life-insurance-guide-part-xvi-one-carrier-or-many";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-12-27 22:15:36";s:17:"post_modified_gmt";s:19:"2015-12-27 22:15:36";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=193";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:9;O:8:"stdClass":23:{s:2:"ID";s:3:"195";s:11:"post_author";s:1:"2";s:9:"post_date";s:19:"2016-01-03 20:35:22";s:13:"post_date_gmt";s:19:"2016-01-03 20:35:22";s:12:"post_content";s:3152:"<strong>Details matter</strong>. That is true of <strong>life insurance</strong> as it is of anything else. Details are also why it is important to judge a policy on more than just <strong>price.</strong>

Everyone has seen the TV commercials for inexpensive life insurance policies that accept everyone, and while they may look good, it's always important to pay attention to the details. Price should never be the only determinant of whether to buy a policy or not.

<h2>Watch for Exclusions</h2>

<strong>Every insurance company is in business to make a profit, and each one's premium structure reflects that</strong>. So if you see one that looks too good to be true, it probably is. That's not something unique to the insurance industry, but it is something you need to be aware of.

<h4>It's All About Exclusions</h4>

Just about every policy has <strong>exclusions</strong>. After all, what's to stop someone with a terminal diagnosis from immediately signing up for a very large policy, knowing they are only going to have to make a single payment. In most cases, that would be seen as abuse, and the company would not have to honor the policy.

The way the insurance companies handle this, and <strong>limit their liability</strong>, is by putting exclusions in their policies. In simplest terms, this means that each policy defines certain circumstances under which the company does not have to pay out to your beneficiary.

While the specifics vary from company to company, and from policy to policy, there are some basics you can rely on. If a policy is very easy to get, and has a very large payout relative to other policies, the chances are that it has a lot more exclusions.

This may not be a problem for some people, but the last person who needs&nbsp;a suprise about your life insurance policy is your beneficiary.

<h2>Always Read The Fine Print</h2>

The best way to deal with this is to always be sure and read the fine print. Regardless of where you get your policy, it has to include a list of all the circumstances in which it will and will not pay out. <strong>A policy with more conditions and limitations will cost you less because it's worth less.</strong> It's that simple.

That's why it's important to compare more than just <strong>premiums</strong> and <strong>payouts</strong> when you are choosing a policy. You have to look at the policy as a whole, and in detail, so that you know exactly what you are and are not getting for your premiums.

The key is to make a list of what is covered, and determine what matters to you. For example, some policies may not cover various <strong>pre-existing conditions</strong>, or even ones&nbsp;that are common in your family. If that's the case, it's important ot know before you sign the policy, and not leave it for your beneficiaries to discover when they are expecting a payout.

Reading the fine print and paying attention to the details makes it possible for you to make an informed decision, not an uninformed one. The more you know, the easier it is to be sure you are making the right decision. Otherwise you might as well be throwing darts while blindfolded.

&nbsp;";s:10:"post_title";s:64:"Life Insurance Guide (Part XVII)  - Pay Attention to the Details";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:4:"open";s:11:"ping_status";s:4:"open";s:13:"post_password";s:0:"";s:9:"post_name";s:59:"life-insurance-guide-part-xvii-pay-attention-to-the-details";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2016-01-03 20:35:22";s:17:"post_modified_gmt";s:19:"2016-01-03 20:35:22";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:43:"http://nationalinsuranceadvisors.com/?p=195";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"post";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}}s:8:"col_info";a:23:{i:0;O:8:"stdClass":13:{s:4:"name";s:2:"ID";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:3;s:8:"not_null";i:1;s:11:"primary_key";i:1;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:1;s:8:"zerofill";i:0;}i:1;O:8:"stdClass":13:{s:4:"name";s:11:"post_author";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:1;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:1;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:1;s:8:"zerofill";i:0;}i:2;O:8:"stdClass":13:{s:4:"name";s:9:"post_date";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:19;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:8:"datetime";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:3;O:8:"stdClass":13:{s:4:"name";s:13:"post_date_gmt";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:19;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:8:"datetime";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:4;O:8:"stdClass":13:{s:4:"name";s:12:"post_content";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:4440;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:5;O:8:"stdClass":13:{s:4:"name";s:10:"post_title";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:73;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:6;O:8:"stdClass":13:{s:4:"name";s:12:"post_excerpt";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:7;O:8:"stdClass":13:{s:4:"name";s:11:"post_status";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:7;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:8;O:8:"stdClass":13:{s:4:"name";s:14:"comment_status";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:4;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:9;O:8:"stdClass":13:{s:4:"name";s:11:"ping_status";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:4;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:10;O:8:"stdClass":13:{s:4:"name";s:13:"post_password";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:11;O:8:"stdClass":13:{s:4:"name";s:9:"post_name";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:69;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:1;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:12;O:8:"stdClass":13:{s:4:"name";s:7:"to_ping";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:13;O:8:"stdClass":13:{s:4:"name";s:6:"pinged";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:14;O:8:"stdClass":13:{s:4:"name";s:13:"post_modified";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:19;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:8:"datetime";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:15;O:8:"stdClass":13:{s:4:"name";s:17:"post_modified_gmt";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:19;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:8:"datetime";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:16;O:8:"stdClass":13:{s:4:"name";s:21:"post_content_filtered";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:17;O:8:"stdClass":13:{s:4:"name";s:11:"post_parent";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:1;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:1;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:1;s:8:"zerofill";i:0;}i:18;O:8:"stdClass":13:{s:4:"name";s:4:"guid";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:43;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:19;O:8:"stdClass":13:{s:4:"name";s:10:"menu_order";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:1;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:20;O:8:"stdClass":13:{s:4:"name";s:9:"post_type";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:4;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:1;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:21;O:8:"stdClass":13:{s:4:"name";s:14:"post_mime_type";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:22;O:8:"stdClass":13:{s:4:"name";s:13:"comment_count";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:1;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}}s:8:"num_rows";i:10;s:10:"return_val";i:10;}