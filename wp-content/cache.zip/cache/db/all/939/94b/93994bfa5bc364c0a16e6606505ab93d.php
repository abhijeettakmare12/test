�xX<?php exit; ?>a:6:{s:10:"last_error";s:0:"";s:10:"last_query";s:215:"SELECT   wp_nia_posts.* FROM wp_nia_posts  WHERE 1=1  AND wp_nia_posts.ID IN (4,87,85,198,14,6) AND wp_nia_posts.post_type = 'page' AND ((wp_nia_posts.post_status = 'publish'))  ORDER BY wp_nia_posts.post_date DESC ";s:11:"last_result";a:6:{i:0;O:8:"stdClass":23:{s:2:"ID";s:3:"198";s:11:"post_author";s:1:"1";s:9:"post_date";s:19:"2016-02-02 07:13:59";s:13:"post_date_gmt";s:19:"2016-02-02 07:13:59";s:12:"post_content";s:0:"";s:10:"post_title";s:12:"Landing Page";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:6:"closed";s:11:"ping_status";s:6:"closed";s:13:"post_password";s:0:"";s:9:"post_name";s:12:"landing-page";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2016-02-02 07:13:59";s:17:"post_modified_gmt";s:19:"2016-02-02 07:13:59";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:49:"http://nationalinsuranceadvisors.com/?page_id=198";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"page";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:1;O:8:"stdClass":23:{s:2:"ID";s:2:"87";s:11:"post_author";s:1:"1";s:9:"post_date";s:19:"2015-10-18 13:16:26";s:13:"post_date_gmt";s:19:"2015-10-18 13:16:26";s:12:"post_content";s:3186:"<p>Here are National Insurance Advisors we pride ourselves in the best life insurance help.</p>

<p>Whether you are looking for help getting a new policy, quote, or help with an existing policy, we are more than willing to help.</p>

<h2>New Policies</h2>

<h3>Advice & Consulting</h3>

<p>At National Insurance Advisors we will help guide you in the right direction for making the best decisions for yourself and your family.</p>

<p>Our process is simple, we determine your needs by asking you a series of questions to custom tailor a policy to specifically solve each one of our customer’s unique problems.</p>

<p>We have all of our licensed advisors trained specifically to help you determine whether a Term, Whole/Permanent, or Universal Life insurance policy will fit your needs best, and exactly the terms on the policy which will benefit you the most.</p>

<h3>Compare Quotes</h3> 

<p>When buying a new policy we know the importance about getting the best deal for your money. That is why during the process we send out an email comparing the policy of your needs with only the highest rated insurance carriers which are all at least an A rating financially by AM Best & Moodys as well as BBB ratings.</p>

<p>From this email you can be sure that you will not only be getting a great deal, but will only be working with the best life insurance carriers.</p>

<p>Some of the carriers we work with are:</p>

<p>Transamerica<br>
Metlife<br>
BannerLife<br>
American International Group (AIG)<br>
Assurity Life Insurance Company<br></p>

<h2>Existing Policies</h2>

<h3>Advice & Consulting</h3>

<p>If you have a current policy, we can give you advice on what to do with claims and dealing with different insurance carriers.</p>

<p>Whether you bought your policy directly from the insurance company or from an insurance broker, we can help guide you should any of your circumstances change.</p>

<p>We can also help lower your rate with your current policy due to improved health and other beneficial circumstances.</p>

<h3>Lower Current Life Insurance Premiums</h3>

<p>With your current policy many policy holders don’t know or utilize the simple facts about lowering their premiums. With many carriers, one can lower their premium cost by retaking a paramedical exam due to improved health.</p>

<p>Another benefit can be a competing insurance carrier which is just as good can offer you better terms and lower premiums. Many insurance companies compete for one another’s business and when insurance companies compete, our clients always win.</p>

<h2>Conclusion</h2>

<p>With the many options on who to choose when buying or asking for insurance advice, we can guarantee a high quality customer service experience whether you are looking to buy a new life insurance policy or get help with an existing one. All of these services are custom tailored to each of our clients unique needs.</p>

<p>Along with getting great customer service we work with many different insurance carriers who compete for your business which is why we can obtain the lowest prices.</p>

<p>Give us a call today, you won't be disappointed.</p>";s:10:"post_title";s:14:"Life Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:6:"closed";s:11:"ping_status";s:6:"closed";s:13:"post_password";s:0:"";s:9:"post_name";s:14:"life-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-11 20:19:45";s:17:"post_modified_gmt";s:19:"2015-11-11 20:19:45";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:38:"http://famouspixel.com/nia/?page_id=87";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"page";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:2;O:8:"stdClass":23:{s:2:"ID";s:2:"85";s:11:"post_author";s:1:"1";s:9:"post_date";s:19:"2015-10-18 13:15:50";s:13:"post_date_gmt";s:19:"2015-10-18 13:15:50";s:12:"post_content";s:2899:"<p>Navigating through the world of life insurance can be very complicated. Especially now with Obama Care, Healthcare.gov, and Open Enrollment Periods. Getting a health insurance policy for yourself shouldn't be.</p>

<p>When working with National Insurance Advisors you will be assigned a personal and licensed insurance advisor which will determine your unique needs and find the best health insurance policy for those needs at the best rate. </p>

<p>Whether it be individual insurance for you or your family or a group insurance policy for your business, we can handle it.</p>

<p>We work with only the most reputable insurance companies in the healthcare industry some which include:</p>

<p>
Aetna<br>
Humana<br>
Cigna<br>
Blue Cross & Blue Shield<br>
United Healthcare<br>
Kaiser Permanente<br>
</p>

<h2>Individual & Family Policies</h2>

<h3>Compare New Policies and Quotes</h3>

<p>Many issues can arise when finding an individual health insurance policy. Such as, Doctor’s covered, deductible costs, in network, and out of network costs, which procedures are covered, maximum out of pocket costs and many more.</p>

<p>Along with help and suggestions from us, we also work with multiple top health insurance carriers who compete for your business to help you get the lowest possible quotes with the best coverage.</p>

<h3>Existing Policy Help</h3>
<p>When working with a health insurance carrier, many issues can arise such as claims denial and high deductible costs which insurance carriers can make difficult to understand.</p>

<p>We work with you understanding your issues with your current policy and can improve your same policy with other insurance carriers willing to compete for your business.</p>

<h2>Group Policies For Businesses</h2>

<h3>Compare New Policies and Quotes</h3>

<p>Finding the right policy for you and your employees can be a daunting task. Especially when your employees depend on you. Luckily, we are here by your side.</p>

<p>Growing your business should be your main focus along with saving money on health insurance for your employees. Getting you top quotes from leading health insurance companies. </p>

<h3>Existing Policy Help</h3>

<p>Along with helping with many of your policy questions such as how much to contribute, tax deductible issues, and many others, we can help save you money per employee.</p>

<p>We understand the many needs of business owners on growing their business and we help them get leading healthcare from top health insurance companies.</p>

<h2>Conclusion</h2>

<p>Whether you are looking for an Individual, Family, or Group Policy, our licensed advisors are ready to help.</p>

<p>Once assigned to an advisor we gather information to give you a custom proposal. Buying a policy from us will ensure a lifetime of peace of mind and insurance help for all of your needs. </p>";s:10:"post_title";s:16:"Health Insurance";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:6:"closed";s:11:"ping_status";s:6:"closed";s:13:"post_password";s:0:"";s:9:"post_name";s:16:"health-insurance";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2016-11-28 15:06:15";s:17:"post_modified_gmt";s:19:"2016-11-28 15:06:15";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:38:"http://famouspixel.com/nia/?page_id=85";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"page";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:3;O:8:"stdClass":23:{s:2:"ID";s:2:"14";s:11:"post_author";s:1:"1";s:9:"post_date";s:19:"2015-10-17 04:11:17";s:13:"post_date_gmt";s:19:"2015-10-17 04:11:17";s:12:"post_content";s:0:"";s:10:"post_title";s:4:"BLOG";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:6:"closed";s:11:"ping_status";s:6:"closed";s:13:"post_password";s:0:"";s:9:"post_name";s:4:"blog";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-10-17 04:11:55";s:17:"post_modified_gmt";s:19:"2015-10-17 04:11:55";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:39:"http://localhost/sandip/nia/?page_id=14";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"page";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:4;O:8:"stdClass":23:{s:2:"ID";s:1:"6";s:11:"post_author";s:1:"1";s:9:"post_date";s:19:"2015-10-17 04:10:28";s:13:"post_date_gmt";s:19:"2015-10-17 04:10:28";s:12:"post_content";s:1666:"<p>At National Insurance Advisors, we take pride us in being one of the leading online insurance brokerage firms who advise and custom tailor policies on a day to day basis.</p>

<p>What differentiates us from our competitors is the highest level of customer service we give to our clients. Here are some of the following key differences: </p>

<h2>Quality Customer Support</h2>
<p>When calling in, we assign you an advisor and stick with that advisor for the rest of your life.</p>

<p>We have access to many different mediums of  communication and can choose the one which fits you best. Whether it be via email, voice, or live chat we work around your busy schedule and help you.</p>

<h2>Unbiased Expert Advice</h2>
<p>When calling in, every single one of our advisors are licensed professionals and can help you with any insurance question you may have. We are experts in multiple types of policies and can advise you properly.</p>

<p>We can help you choose and compare quotes for the right insurance company for you. We don't favor any insurance companies and choose the one which is right for you.</p>

<h2>Real And Accurate Quoting</h2>
<p>At NIA we use custom internal tools which are linked up to insurance carriers and will give you the most updated information. We assess each one of our clients needs individually to give them an accurate quote rather a one size fits all solution.</p>

<h2>Conclusion</h2>
<p>What separates us from everyone else is the quality customer support we give and the expert custom advice to each one of our clients.</p>

<p>When choosing where to buy insurance we always make sure our clients are #1.</p>";s:10:"post_title";s:8:"ABOUT US";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:6:"closed";s:11:"ping_status";s:6:"closed";s:13:"post_password";s:0:"";s:9:"post_name";s:8:"about-us";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2015-11-13 16:48:23";s:17:"post_modified_gmt";s:19:"2015-11-13 16:48:23";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:38:"http://localhost/sandip/nia/?page_id=6";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"page";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}i:5;O:8:"stdClass":23:{s:2:"ID";s:1:"4";s:11:"post_author";s:1:"1";s:9:"post_date";s:19:"2015-10-17 04:10:18";s:13:"post_date_gmt";s:19:"2015-10-17 04:10:18";s:12:"post_content";s:0:"";s:10:"post_title";s:4:"HOME";s:12:"post_excerpt";s:0:"";s:11:"post_status";s:7:"publish";s:14:"comment_status";s:6:"closed";s:11:"ping_status";s:6:"closed";s:13:"post_password";s:0:"";s:9:"post_name";s:4:"home";s:7:"to_ping";s:0:"";s:6:"pinged";s:0:"";s:13:"post_modified";s:19:"2016-11-28 15:40:47";s:17:"post_modified_gmt";s:19:"2016-11-28 15:40:47";s:21:"post_content_filtered";s:0:"";s:11:"post_parent";s:1:"0";s:4:"guid";s:38:"http://localhost/sandip/nia/?page_id=4";s:10:"menu_order";s:1:"0";s:9:"post_type";s:4:"page";s:14:"post_mime_type";s:0:"";s:13:"comment_count";s:1:"0";}}s:8:"col_info";a:23:{i:0;O:8:"stdClass":13:{s:4:"name";s:2:"ID";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:3;s:8:"not_null";i:1;s:11:"primary_key";i:1;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:1;s:8:"zerofill";i:0;}i:1;O:8:"stdClass":13:{s:4:"name";s:11:"post_author";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:1;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:1;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:1;s:8:"zerofill";i:0;}i:2;O:8:"stdClass":13:{s:4:"name";s:9:"post_date";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:19;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:8:"datetime";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:3;O:8:"stdClass":13:{s:4:"name";s:13:"post_date_gmt";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:19;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:8:"datetime";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:4;O:8:"stdClass":13:{s:4:"name";s:12:"post_content";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:3186;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:5;O:8:"stdClass":13:{s:4:"name";s:10:"post_title";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:16;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:6;O:8:"stdClass":13:{s:4:"name";s:12:"post_excerpt";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:7;O:8:"stdClass":13:{s:4:"name";s:11:"post_status";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:7;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:8;O:8:"stdClass":13:{s:4:"name";s:14:"comment_status";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:6;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:9;O:8:"stdClass":13:{s:4:"name";s:11:"ping_status";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:6;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:10;O:8:"stdClass":13:{s:4:"name";s:13:"post_password";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:11;O:8:"stdClass":13:{s:4:"name";s:9:"post_name";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:16;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:1;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:12;O:8:"stdClass":13:{s:4:"name";s:7:"to_ping";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:13;O:8:"stdClass":13:{s:4:"name";s:6:"pinged";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:14;O:8:"stdClass":13:{s:4:"name";s:13:"post_modified";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:19;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:8:"datetime";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:15;O:8:"stdClass":13:{s:4:"name";s:17:"post_modified_gmt";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:19;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:8:"datetime";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:16;O:8:"stdClass":13:{s:4:"name";s:21:"post_content_filtered";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:1;s:4:"type";s:4:"blob";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:17;O:8:"stdClass":13:{s:4:"name";s:11:"post_parent";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:1;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:1;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:1;s:8:"zerofill";i:0;}i:18;O:8:"stdClass":13:{s:4:"name";s:4:"guid";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:49;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:19;O:8:"stdClass":13:{s:4:"name";s:10:"menu_order";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:1;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:20;O:8:"stdClass":13:{s:4:"name";s:9:"post_type";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:4;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:1;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:21;O:8:"stdClass":13:{s:4:"name";s:14:"post_mime_type";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:0;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:0;s:4:"blob";i:0;s:4:"type";s:6:"string";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}i:22;O:8:"stdClass":13:{s:4:"name";s:13:"comment_count";s:5:"table";s:12:"wp_nia_posts";s:3:"def";s:0:"";s:10:"max_length";i:1;s:8:"not_null";i:1;s:11:"primary_key";i:0;s:12:"multiple_key";i:0;s:10:"unique_key";i:0;s:7:"numeric";i:1;s:4:"blob";i:0;s:4:"type";s:3:"int";s:8:"unsigned";i:0;s:8:"zerofill";i:0;}}s:8:"num_rows";i:6;s:10:"return_val";i:6;}